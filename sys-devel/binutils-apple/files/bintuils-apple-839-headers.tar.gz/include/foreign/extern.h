#define __private_extern__ __attribute__((visibility("hidden")))
